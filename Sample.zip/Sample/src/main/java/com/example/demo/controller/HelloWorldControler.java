package com.example.demo.controller;


import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController

public class HelloWorldControler 
{
	
	@RequestMapping("/")
	public String healthCheck() {
		return "OK";
	}
    
    @GetMapping(path="/welcome", produces = "application/json")
   
	public String getMessage() {
		return "Evrthing in Life is achievable, if one strives hard for it";
	}
	
	
}